from django.contrib import admin
from tvshows.models import *
# Register your models here.
admin.site.register(Show)
admin.site.register(Show_Rating)